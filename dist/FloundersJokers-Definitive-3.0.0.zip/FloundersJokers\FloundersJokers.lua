-- Flounder's original Joker catalogue, maintained through Steamodded's
-- official 0.9.8 compatibility adapter. Modern objects live in main.lua and
-- modules/. The original pre-migration source is preserved in archive/.

local defaults = {
    -- Jokers
    commonJoker = true,
    uncommonJoker = true,
    rareJoker = true,
    legendaryJoker = true,
	luckyStone = true,
	crackedStone = true,
	shinyStone = true,
	crystalizedStone = true,
	luxuryStone = true,
	moonStone = true,
	sunStone = true,
	spearHead = true,
	bulletTip = true,
	missileTip = true,
	crystalMagazine = true,
	sunGun = true,
	spaceLaser = true,
	solarFlare = true,
	bloodGem = true,
	lostGem = true,
	sunkenGem = true,
	loveGem = true,
	holyGem = true,
	radiationGem = true,
	apolloGem = true,
	imperialTopaz = true,
	mozambiqueRuby = true,
	pinkPanther = true,
	blackDiamond = true,
	goldBar = true,
	meteorPiece = true,
	starPlasma = true,
	gunsandRoses = true,
	fishandChips = true,
	saltandPepper = true,
	macaroniandCheese = true,
	breadandButter = true,
	rhythmandBlues = true,
	moonandSun = true,
	sunandMoon = true,
	kingsWrath = true,
	theRobber = true,
	hungrySorcerer = true,
	glassBlower = true,
	enchancedSediment = true,
	bornWild = true,
	mathMatician = true,
	theBoss = true,
	overtheRainbow = true,
	witchDoctor = true,
	palmReader = true,
	painTer = true,
	diRector = true,
	orbit = true,
	
}

local config = (SMODS.current_mod and SMODS.current_mod.config) or {}
for key, value in pairs(defaults) do
    if config[key] == nil then config[key] = value end
end

local function mod_loaded(...)
    for _, id in ipairs({...}) do
        local mod = SMODS.Mods and SMODS.Mods[id]
        if mod and mod.can_load ~= false and not mod.disabled then return true end
    end
    return false
end

local function fj_roll(card)
    local center = card and card.config and card.config.center
    local key = center and center.key or (card and card.ability and card.ability.name) or 'unknown'
    return pseudorandom('fj_' .. tostring(key))
end

local seals = {
    "Gold",
    "Red",
    "Blue",
    "Purple"
}

local function tables_equal(a, b)
    return table.concat(a) == table.concat(b)
end

local function tables_copy(t)
    local t2 = {}
    for k, v in pairs(t) do
        t2[k] = v
    end
    return t2
end

-- Save attributes
local attributes = {
    mult = {
        key = 'mult_dagonet',
        prev_key = 'prev_mult_dagonet',
        min = 0
    },
    mult_mod = {
        key = 'mult_mod_dagonet',
        prev_key = 'prev_mult_mod_dagonet',
        min = 0
    },
    chips = {
        key = 'chips_dagonet',
        prev_key = 'prev_chips_dagonet',
        min = 0
    },
    chip_mod = {
        key = 'chip_mod_dagonet',
        prev_key = 'prev_chips_mod_dagonet',
        min = 0
    },
    Xmult = {
        key = 'Xmult_dagonet',
        prev_key = 'prev_Xmult_dagonet',
        min = 1
    },
    Xmult_mod = {
        key = 'Xmult_mod_dagonet',
        prev_key = 'prev_Xmult_mod_dagonet',
        min = 0
    },
    x_mult = {
        key = 'x_mult_dagonet',
        prev_key = 'prev_x_mult_dagonet',
        min = 1
    },
    t_mult = {
        key = 't_mult_dagonet',
        prev_key = 'prev_t_mult_dagonet',
        min = 0
    },
    t_chips = {
        key = 't_chips_dagonet',
        prev_key = 'prev_t_chips_dagonet',
        min = 0
    },
    s_mult = {
        key = 's_mult_dagonet',
        prev_key = 'prev_s_mult_dagonet',
        min = 0
    },
    dollars = {
        key = 'dollars_dagonet',
        prev_key = 'prev_dollars_dagonet',
        min = 0
    },
    hand_add = {
        key = 'hand_add_dagonet',
        prev_key = 'prev_hand_add_dagonet',
        min = 0
    },
    discard_sub = {
        key = 'discard_sub_dagonet',
        prev_key = 'prev_discard_sub_dagonet',
        min = 0
    },
    odds = {
        key = 'odds_dagonet',
        prev_key = 'prev_odds_dagonet',
        min = 0
    },
    faces = {
        key = 'faces_dagonet',
        prev_key = 'prev_faces_dagonet',
        min = 0
    },
    max = {
        key = 'max_dagonet',
        prev_key = 'prev_max_dagonet',
        min = 0
    },
    min = {
        key = 'min_dagonet',
        prev_key = 'prev_min_dagonet',
        min = 0
    },
    every = {
        key = 'every_dagonet',
        prev_key = 'prev_every_dagonet',
        min = 0
    },
    increase = {
        key = 'increase_dagonet',
        prev_key = 'prev_increase_dagonet',
        min = 0
    },
    d_size = {
        key = 'd_size_dagonet',
        prev_key = 'prev_d_size_dagonet',
        min = 0
    },
    h_mod = {
        key = 'h_mod_dagonet',
        prev_key = 'prev_h_mod_dagonet',
        min = 0
    },
    h_plays = {
        key = 'h_plays_dagonet',
        prev_key = 'prev_h_plays_dagonet',
        min = 0
    },
    discards = {
        key = 'discards_dagonet',
        prev_key = 'prev_discards_dagonet',
        min = 0
    },
    req = {
        key = 'req_dagonet',
        prev_key = 'prev_req_dagonet',
        min = 0
    },
    percentage = {
        key = 'percentage_dagonet',
        prev_key = 'prev_percentage_dagonet',
        min = 0
    },
    base = {
        key = 'base_dagonet',
        prev_key = 'prev_base_dagonet',
        min = 0
    },
    repetitions = {
        key = 'repetitions_dagonet',
        prev_key = 'prev_repetitions_dagonet',
        min = 0
    },
    dollar_gain_one = {
        key = 'dollar_gain_one_dagonet',
        prev_key = 'prev_dollar_gain_one_dagonet',
        min = 0
    },
    dollar_gain_two = {
        key = 'dollar_gain_two_dagonet',
        prev_key = 'prev_dollar_gain_two_dagonet',
        min = 0
    },
    dollar_gain_three = {
        key = 'dollar_gain_three_dagonet',
        prev_key = 'prev_dollar_gain_three_dagonet',
        min = 0
    },
    dollar_gain_four = {
        key = 'dollar_gain_four_dagonet',
        prev_key = 'prev_dollar_gain_four_dagonet',
        min = 0
    },
    dollar_gain_five = {
        key = 'dollar_gain_five_dagonet',
        prev_key = 'prev_dollar_gain_five_dagonet',
        min = 0
    },
    extra = {
        key = 'extra_dagonet',
        prev_key = 'prev_extra_dagonet',
        min = 0
    }
}
local function create_tarot(joker, tarot)
    -- Check consumeable space
    if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
        -- Add card
        G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
        G.E_MANAGER:add_event(Event({
           trigger = 'before',
           delay = 0.0,
           func = (function()
               local card = create_card('Tarot', G.consumeables, nil, nil, nil, nil, tarot, '8ba')
               card:add_to_deck()
               G.consumeables:emplace(card)
               G.GAME.consumeable_buffer = 0
               return true
           end)
        }))

        -- Show message
        card_eval_status_text(joker, 'extra', nil, nil, nil, {
           message = localize('k_plus_tarot'),
           colour = G.C.PURPLE
        })
    else
        card_eval_status_text(joker, 'extra', nil, nil, nil, {
            message = localize('k_no_space_ex')
        })
    end
	
end

local function create_planet(joker, planet, other_joker)
    if #G.consumeables.cards + G.GAME.consumeable_buffer <
        G.consumeables.config.card_limit then
        G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
        -- Add card
        G.E_MANAGER:add_event(Event({
            trigger = 'before',
            delay = 0.0,
            func = (function()
                local card = create_card('Planet', G.consumeables, nil, nil, nil, nil, planet, 'blusl')
                card:add_to_deck()
                G.consumeables:emplace(card)
                G.GAME.consumeable_buffer = 0
                if other_joker then
                    other_joker:juice_up(0.5, 0.5)
                end
                return true
            end)
        }))

        -- Show message
        card_eval_status_text(joker, 'extra', nil, nil, nil, {
            message = localize('k_plus_planet'),
            colour = G.C.SECONDARY_SET.Planet
        })
    else
        card_eval_status_text(joker, 'extra', nil, nil, nil, {
            message = localize('k_no_space_ex')
        })
    end
end

local function create_joker(joker, cjoker, rarity)
    -- Check consumeable space
    if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
        -- Add card
        G.GAME.joker_buffer = G.GAME.joker_buffer + 1
        G.E_MANAGER:add_event(Event({
           trigger = 'before',
           delay = 0.0,
           func = (function()
               local card = create_card('Joker', G.jokers, rarity, nil, nil, nil, cjoker, 'len')
               card:add_to_deck()
               G.jokers:emplace(card)
               G.GAME.joker_buffer = 0
               return true
           end)
        }))

        -- Show message
        card_eval_status_text(joker, 'extra', nil, nil, nil, {
           message = localize('k_plus_joker'),
           colour = G.C.PURPLE
        })
    else
        card_eval_status_text(joker, 'extra', nil, nil, nil, {
            message = localize('k_no_space_ex')
        })
    end
end

-- Increase base attributes
local function increase_attributes(k, v, place, multiplier)
    local attr = attributes[k]

    if not attr or type(v) == "string" then
        return
    end

    -- Handle extra seperately
    if type(v) == "table" then
        for k2, v2 in pairs(place.extra) do
            increase_attributes(k2, v2, place.extra, multiplier)
        end
    elseif v > attr.min then
        if place[attr.prev_key] == nil then
            place[attr.prev_key] = multiplier
        end
        if place[attr.key] == nil then
            -- Save base value
            place[attr.key] = v
        else
            if not (v / multiplier == place[attr.key] and place[attr.prev_key] == multiplier) then
                if not (v / multiplier == place[attr.key] or v / place[attr.prev_key] == place[attr.key]) then
                    if v / multiplier ~= place[attr.key] and place[attr.prev_key] == multiplier then
                        -- Update base based on current multiplier
                        local increase = (v / multiplier - place[attr.key]) * multiplier
                        place[attr.key] = place[attr.key] + increase
                    else
                        -- Update base based on previous multiplier
                        local increase = (v / place[attr.prev_key] - place[attr.key]) * place[attr.prev_key]
                        place[attr.key] = place[attr.key] + increase
                    end
                end
            end
        end
        -- Multiply attribute
        place[k] = place[attr.key] * multiplier
        place[attr.prev_key] = multiplier
    end
end

local function not_in_table(table, value)
    for _, v in ipairs(table) do
        if v == value then
            return false
        end
    end
    return true
end

function SMODS.INIT.flounderjokers()

    G.localization.misc.v_dictionary.fj_tags = {"+#1# #2#!"}

    init_localization()

    local flounderJokers = SMODS.findModByID('flounderjokers')

    if config.commonJoker then
        -- Create Common Joker
        local cojo = {
            loc = {
                name = "Common Joker",
                text = {
                    "{C:green}rerolls{} have {C:green}#2# in #1#{} chance",
                    "add a {C:green}Uncommon Tag{}"
                }
            },
            ability_name = "commonJoker",
            slug = "common",
            ability = {
                extra = {odds = 5, tags = 1, tag = 'tag_uncommon', tag_name = 'Uncommon tag'}
            },
            rarity = 1,
            cost = 4,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Common Joker
        local joker_cojo = SMODS.Joker:new(
            cojo.ability_name,
            cojo.slug,
            cojo.ability,
            { x = 0, y = 0 },
            cojo.loc,
            cojo.rarity,
            cojo.cost,
            cojo.unlocked,
            cojo.discovered,
            cojo.blueprint_compat,
            cojo.eternal_compat,
            nil,
            cojo.slug
        )
        joker_cojo:register()

        -- Initialize Sprite for Jokers
        local sprite_cojo = SMODS.Sprite:new(
            cojo.slug,
            flounderJokers.path,
            "j_" .. cojo.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_cojo:register()

        -- Set local variables for Common Joker
        function joker_cojo.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1),self.ability.extra.tags, self.ability.extra.tag, self.ability.extra.tag_name}
        end
        -- Calculate
        joker_cojo.calculate = function(self, context)
            if context.reroll_shop and not context.individual and not context.repetition and not context.blueprint then
                if fj_roll(self) < G.GAME.probabilities.normal / self.ability.extra.odds then
                        if FJ_EFFECT then FJ_EFFECT(self) end
                    G.E_MANAGER:add_event(Event({func = function()
                        add_tag(Tag(self.ability.extra.tag))
                    return true end }))
                    return {
                        message = localize {
                            type = 'variable',
                            key= 'fj_tags',
                            vars = {self.ability.extra.tags, self.ability.extra.tag_name}  
                        }
                    }
                end 
            end
        end
    end
    if config.uncommonJoker then
        -- Create Uncommon Joker
        local unjo = {
            loc = {
                name = "Uncommon Joker",
                text = {
                    "{C:green}rerolls{} have {C:green}#2# in #1#{} chance",
                    "add a {C:red}Rare Tag{}"
                }
            },
            ability_name = "uncommonJoker",
            slug = "uncommon",
            ability = {
                extra = {odds = 8, tags = 1, tag = 'tag_rare', tag_name = 'Rare tag'}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Uncommon Joker
        local joker_unjo = SMODS.Joker:new(
            unjo.ability_name,
            unjo.slug,
            unjo.ability,
            { x = 0, y = 0 },
            unjo.loc,
            unjo.rarity,
            unjo.cost,
            unjo.unlocked,
            unjo.discovered,
            unjo.blueprint_compat,
            unjo.eternal_compat,
            nil,
            unjo.slug
        )
        joker_unjo:register()

        local sprite_unjo = SMODS.Sprite:new(
            unjo.slug,
            flounderJokers.path,
            "j_" .. unjo.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_unjo:register()

        function joker_unjo.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1),self.ability.extra.tags, self.ability.extra.tag, self.ability.extra.tag_name}
        end
        -- Calculate
        joker_unjo.calculate = function(self, context)
            if context.reroll_shop and not context.individual and not context.repetition and not context.blueprint then
                if fj_roll(self) < G.GAME.probabilities.normal / self.ability.extra.odds then
                        if FJ_EFFECT then FJ_EFFECT(self) end
                    G.E_MANAGER:add_event(Event({func = function()
                        add_tag(Tag(self.ability.extra.tag))
                    return true end }))
                    return {
                        message = localize {
                            type = 'variable',
                            key= 'fj_tags',
                            vars = {self.ability.extra.tags, self.ability.extra.tag_name}  
                        }
                    }
                end 
            end
        end
    end
    if config.rareJoker then
        -- Create Rare Joker
        local rajo = {
            loc = {
                name = "Rare Joker",
                text = {
                    "{C:green}rerolls{} have {C:green}#2# in #1#{} chance",
                    "add a {C:purple}Legendary{} Joker"
                }
            },
            ability_name = "rareJoker",
            slug = "rare",
            ability = {
                extra = {odds = 20, spectrals = 1, spectral = 'c_soul', spectral_name = 'The Soul'}
            },
            rarity = 3,
            cost = 8,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Rare Joker
        local joker_rajo = SMODS.Joker:new(
            rajo.ability_name,
            rajo.slug,
            rajo.ability,
            { x = 0, y = 0 },
            rajo.loc,
            rajo.rarity,
            rajo.cost,
            rajo.unlocked,
            rajo.discovered,
            rajo.blueprint_compat,
            rajo.eternal_compat,
            nil,
            rajo.slug
        )
        joker_rajo:register()

        local sprite_rajo = SMODS.Sprite:new(
            rajo.slug,
            flounderJokers.path,
            "j_" .. rajo.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_rajo:register()

        function joker_rajo.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1),self.ability.extra.spectrals, self.ability.extra.spectral, self.ability.extra.spectral_name}
        end
        -- Calculate
        joker_rajo.calculate = function(self, context)
            if context.reroll_shop and not context.individual and not context.repetition and not context.blueprint then
                if fj_roll(self) < G.GAME.probabilities.normal / self.ability.extra.odds then
                        if FJ_EFFECT then FJ_EFFECT(self) end
                     create_joker(self, nil, "legendary")  --creates a random legendary joker
                 end
             end
         end
    end
    if config.legendaryJoker then
        -- Create Legendary Joker
        local lejo = {
            loc = {
                name = "Legendary Joker",
                text = {
                    "{C:green}rerolls{} have {C:green}#2# in #1#{} chance",
                    "add a {C:dark_edition}Negative Tag{}"
                }
            },
            ability_name = "legendaryJoker",
            slug = "legendary",
            ability = {
                extra = {odds = 25, tags = 1, tag = 'tag_negative', tag_name = 'Negative tag'}
            },
            rarity = 4,
            cost = 12,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Legendary Joker
        local joker_lejo = SMODS.Joker:new(
            lejo.ability_name,
            lejo.slug,
            lejo.ability,
            { x = 0, y = 0 },
            lejo.loc,
            lejo.rarity,
            lejo.cost,
            lejo.unlocked,
            lejo.discovered,
            lejo.blueprint_compat,
            lejo.eternal_compat,
            nil,
            lejo.slug
        )
        joker_lejo:register()

        local sprite_lejo = SMODS.Sprite:new(
            lejo.slug,
            flounderJokers.path,
            "j_" .. lejo.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_lejo:register()

        function joker_lejo.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1),self.ability.extra.tags, self.ability.extra.tag, self.ability.extra.tag_name}
        end
        -- Calculate
        joker_lejo.calculate = function(self, context)
            if context.reroll_shop and not context.individual and not context.repetition and not context.blueprint then
                if fj_roll(self) < G.GAME.probabilities.normal / self.ability.extra.odds then
                        if FJ_EFFECT then FJ_EFFECT(self) end
                    G.E_MANAGER:add_event(Event({func = function()
                        add_tag(Tag(self.ability.extra.tag))
                    return true end }))
                    return {
                        message = localize {
                            type = 'variable',
                            key= 'fj_tags',
                            vars = {self.ability.extra.tags, self.ability.extra.tag_name}  
                        }
                    }
                end 
            end
        end
    end
  	if config.luckyStone then
        -- Create Lucky Stone
        local lust = {
            loc = {
                name = "Lucky Stone",
                text = {
                    "{C:green}#2# in #1#{} chance for",
                    "played cards with {C:clubs}Club{} suit",
					"to give {X:mult,C:white}X#3#{} mult when scored"
                }
            },
            ability_name = "luckyStone",
            slug = "lucky",
            ability = {
                extra = {odds = 2, Xmult = 1.5}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Lucky Stone
        local joker_lust = SMODS.Joker:new(
            lust.ability_name,
            lust.slug,
            lust.ability,
            { x = 0, y = 0 },
            lust.loc,
            lust.rarity,
            lust.cost,
            lust.unlocked,
            lust.discovered,
            lust.blueprint_compat,
            lust.eternal_compat,
            nil,
            lust.slug
        )
        joker_lust:register()

        -- Initialize Sprite for Jokers
        local sprite_lust = SMODS.Sprite:new(
            lust.slug,
            flounderJokers.path,
            "j_" .. lust.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_lust:register()

        -- Set local variables for Lucky Stone
        function joker_lust.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1),self.ability.extra.Xmult}
        end
        -- Calculate
        joker_lust.calculate = function(self, context)
	       if self.ability.name ==  'luckyStone' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Clubs") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then
                        if FJ_EFFECT then FJ_EFFECT(self) end
                        return {
                            x_mult = self.ability.extra.Xmult,
                            card = self
                        }
                    end
			    end
            end	
	    end
	end
    if config.crackedStone then
        -- Create Cracked Stone
        local crst = {
            loc = {
                name = "Cracked Stone",
                text = {
                    "{C:green}#2# in #1#{} chance for",
                    "played cards with {C:spades}Spade{} suit",
					"to give {X:mult,C:white}X#3#{} mult when scored"
                }
            },
            ability_name = "crackedStone",
            slug = "cracked",
            ability = {
                extra = {odds = 2, Xmult = 1.5}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Cracked Stone
        local joker_crst = SMODS.Joker:new(
            crst.ability_name,
            crst.slug,
            crst.ability,
            { x = 0, y = 0 },
            crst.loc,
            crst.rarity,
            crst.cost,
            crst.unlocked,
            crst.discovered,
            crst.blueprint_compat,
            crst.eternal_compat,
            nil,
            crst.slug
        )
        joker_crst:register()

        -- Initialize Sprite for Jokers
        local sprite_crst = SMODS.Sprite:new(
            crst.slug,
            flounderJokers.path,
            "j_" .. crst.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_crst:register()

        -- Set local variables for Cracked Stone
        function joker_crst.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1),self.ability.extra.Xmult}
        end
        -- Calculate
        joker_crst.calculate = function(self, context)
	       if self.ability.name ==  'crackedStone' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Spades") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then
                        if FJ_EFFECT then FJ_EFFECT(self) end
                        return {
                            x_mult = self.ability.extra.Xmult,
                            card = self
                        }
                    end
                end
	        end
		end
	end
    if config.shinyStone then
        -- Create Shiny Stone
        local shst = {
            loc = {
                name = "Shiny Stone",
                text = {
                    "{C:green}#2# in #1#{} chance for",
                    "played cards with {C:diamonds}Diamond{} suit",
					"to give {X:mult,C:white}X#3#{} mult when scored"
                }
            },
            ability_name = "shinyStone",
            slug = "shiny",
            ability = {
                extra = {odds = 2, Xmult = 1.5}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Shiny Stone
        local joker_shst = SMODS.Joker:new(
            shst.ability_name,
            shst.slug,
            shst.ability,
            { x = 0, y = 0 },
            shst.loc,
            shst.rarity,
            shst.cost,
            shst.unlocked,
            shst.discovered,
            shst.blueprint_compat,
            shst.eternal_compat,
            nil,
            shst.slug
        )
        joker_shst:register()

        -- Initialize Sprite for Jokers
        local sprite_shst = SMODS.Sprite:new(
            shst.slug,
            flounderJokers.path,
            "j_" .. shst.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_shst:register()

        -- Set local variables for Shiny Stone
        function joker_shst.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1),self.ability.extra.Xmult}
        end
		-- Calculate
        joker_shst.calculate = function(self, context)
	       if self.ability.name ==  'shinyStone' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Diamonds") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then
                        if FJ_EFFECT then FJ_EFFECT(self) end
                        return {
                            x_mult = self.ability.extra.Xmult,
                            card = self
                        }		
	                end
				end
			end
		end
	end
    if config.spearHead then
        -- Create Spear Head
        local sphe = {
            loc = {
                name = "Spear Head",
                text = {
                    "Played cards with",
                    "{C:clubs}Club{} suit give",
					"{C:chips}+#1#{} Chips when scored"
                }
            },
            ability_name = "spearHead",
            slug = "spear",
            ability = {
                extra = {chips = 50}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Spear Head
        local joker_sphe = SMODS.Joker:new(
            sphe.ability_name,
            sphe.slug,
            sphe.ability,
            { x = 0, y = 0 },
            sphe.loc,
            sphe.rarity,
            sphe.cost,
            sphe.unlocked,
            sphe.discovered,
            sphe.blueprint_compat,
            sphe.eternal_compat,
            nil,
            sphe.slug
        )
        joker_sphe:register()

        -- Initialize Sprite for Jokers
        local sprite_sphe = SMODS.Sprite:new(
            sphe.slug,
            flounderJokers.path,
            "j_" .. sphe.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_sphe:register()

        -- Set local variables for Spear Head
        function joker_sphe.loc_def(self)
            return { self.ability.extra.chips}
        end
		-- Calculate
        joker_sphe.calculate = function(self, context)
	       if self.ability.name ==  'spearHead' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Clubs") then
                    return {
                        chips = self.ability.extra.chips,
                        card = self
                    }		
				end
			end
		end
	end
	if config.bulletTip then
        -- Create Bullet Tip
        local buti = {
            loc = {
                name = "Bullet Tip",
                text = {
                    "Played cards with",
                    "{C:diamonds}Diamond{} suit give",
					"{C:chips}+#1#{} Chips when scored"
                }
            },
            ability_name = "bulletTip",
            slug = "bullet",
            ability = {
                extra = {chips = 50}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Shiny Stone
        local joker_buti = SMODS.Joker:new(
            buti.ability_name,
            buti.slug,
            buti.ability,
            { x = 0, y = 0 },
            buti.loc,
            buti.rarity,
            buti.cost,
            buti.unlocked,
            buti.discovered,
            buti.blueprint_compat,
            buti.eternal_compat,
            nil,
            buti.slug
        )
        joker_buti:register()

        -- Initialize Sprite for Jokers
        local sprite_buti = SMODS.Sprite:new(
            buti.slug,
            flounderJokers.path,
            "j_" .. buti.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_buti:register()

        -- Set local variables for Bullet Tip
        function joker_buti.loc_def(self)
            return { self.ability.extra.chips}
        end
		-- Calculate
        joker_buti.calculate = function(self, context)
	       if self.ability.name ==  'bulletTip' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Diamonds") then
                    return {
                        chips = self.ability.extra.chips,
                        card = self
                    }		
				end
			end
		end
	end
    if config.missileTip then
        -- Create Missile Tip
        local miti = {
            loc = {
                name = "Missile Tip",
                text = {
                    "Played cards with",
                    "{C:red}Heart{} suit give",
					"{C:chips}+#1#{} Chips when scored"
                }
            },
            ability_name = "missileTip",
            slug = "missile",
            ability = {
                extra = {chips = 50}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Missile Tip
        local joker_miti = SMODS.Joker:new(
            miti.ability_name,
            miti.slug,
            miti.ability,
            { x = 0, y = 0 },
            miti.loc,
            miti.rarity,
            miti.cost,
            miti.unlocked,
            miti.discovered,
            miti.blueprint_compat,
            miti.eternal_compat,
            nil,
            miti.slug
        )
        joker_miti:register()

        -- Initialize Sprite for Jokers
        local sprite_miti = SMODS.Sprite:new(
            miti.slug,
            flounderJokers.path,
            "j_" .. miti.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_miti:register()

        -- Set local variables for Missile Tip
        function joker_miti.loc_def(self)
            return { self.ability.extra.chips}
        end
		-- Calculate
        joker_miti.calculate = function(self, context)
	       if self.ability.name ==  'missileTip' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Hearts") then
                    return {
                        chips = self.ability.extra.chips,
                        card = self
                    }		
				end
			end
		end
	end
    if config.bloodGem then
        -- Create Blood Gem
        local blge = {
            loc = {
                name = "Blood Gem",
                text = {
                    "Played cards with",
                    "{C:red}Heart{} suit give",
					"{C:money}$#1#{} when scored"
                }
            },
            ability_name = "bloodGem",
            slug = "blood",
            ability = {
                extra = {money = 1}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Blood Gem
        local joker_blge = SMODS.Joker:new(
            blge.ability_name,
            blge.slug,
            blge.ability,
            { x = 0, y = 0 },
            blge.loc,
            blge.rarity,
            blge.cost,
            blge.unlocked,
            blge.discovered,
            blge.blueprint_compat,
            blge.eternal_compat,
            nil,
            blge.slug
        )
        joker_blge:register()

        -- Initialize Sprite for Jokers
        local sprite_blge = SMODS.Sprite:new(
            blge.slug,
            flounderJokers.path,
            "j_" .. blge.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_blge:register()

        -- Set local variables for Blood Gem
        function joker_blge.loc_def(self)
            return { self.ability.extra.money}
        end
		-- Calculate
        joker_blge.calculate = function(self, context)
	       if self.ability.name ==  'bloodGem' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Hearts") then
                    G.GAME.dollar_buffer = (G.GAME.dollar_buffer or 0) + self.ability.extra.money
					G.E_MANAGER:add_event(Event({func = (function() G.GAME.dollar_buffer = 0; return true end)}))
                    return {
                        dollars = self.ability.extra.money,
                        card = self
                    }		
				end
			end
		end
	end
    if config.lostGem then
        -- Create Lost Gem
        local loge = {
            loc = {
                name = "Lost Gem",
                text = {
                    "Played cards with",
                    "{C:spades}Spade{} suit give",
					"{C:money}$#1#{} when scored"
                }
            },
            ability_name = "lostGem",
            slug = "lost",
            ability = {
                extra = {money = 1}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Lost Gem
        local joker_loge = SMODS.Joker:new(
            loge.ability_name,
            loge.slug,
            loge.ability,
            { x = 0, y = 0 },
            loge.loc,
            loge.rarity,
            loge.cost,
            loge.unlocked,
            loge.discovered,
            loge.blueprint_compat,
            loge.eternal_compat,
            nil,
            loge.slug
        )
        joker_loge:register()

        -- Initialize Sprite for Jokers
        local sprite_loge = SMODS.Sprite:new(
            loge.slug,
            flounderJokers.path,
            "j_" .. loge.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_loge:register()

        -- Set local variables for Lost Gem
        function joker_loge.loc_def(self)
            return { self.ability.extra.money}
        end
		-- Calculate
        joker_loge.calculate = function(self, context)
	       if self.ability.name ==  'lostGem' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Spades") then
                    G.GAME.dollar_buffer = (G.GAME.dollar_buffer or 0) + self.ability.extra.money
					G.E_MANAGER:add_event(Event({func = (function() G.GAME.dollar_buffer = 0; return true end)}))
                    return {
                        dollars = self.ability.extra.money,
                        card = self
                    }		
				end
			end
		end
	end
    if config.sunkenGem then
        -- Create Sunken Gem
        local suge = {
            loc = {
                name = "Sunken Gem",
                text = {
                    "Played cards with",
                    "{C:clubs}Club{} suit give",
					"{C:money}$#1#{} when scored"
                }
            },
            ability_name = "sunkenGem",
            slug = "sunken",
            ability = {
                extra = {money = 1}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Sunken Gem
        local joker_suge = SMODS.Joker:new(
            suge.ability_name,
            suge.slug,
            suge.ability,
            { x = 0, y = 0 },
            suge.loc,
            suge.rarity,
            suge.cost,
            suge.unlocked,
            suge.discovered,
            suge.blueprint_compat,
            suge.eternal_compat,
            nil,
            suge.slug
        )
        joker_suge:register()

        -- Initialize Sprite for Jokers
        local sprite_suge = SMODS.Sprite:new(
            suge.slug,
            flounderJokers.path,
            "j_" .. suge.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_suge:register()

        -- Set local variables for Sunken Gem
        function joker_suge.loc_def(self)
            return { self.ability.extra.money}
        end
		-- Calculate
        joker_suge.calculate = function(self, context)
	       if self.ability.name ==  'sunkenGem' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Clubs") then
                    G.GAME.dollar_buffer = (G.GAME.dollar_buffer or 0) + self.ability.extra.money
					G.E_MANAGER:add_event(Event({func = (function() G.GAME.dollar_buffer = 0; return true end)}))
                    return {
                        dollars = self.ability.extra.money,
                        card = self
                    }		
				end
			end
		end
	end
    if config.imperialTopaz then
        -- Create Imperial Topaz
        local imto = {
            loc = {
                name = "Imperial Topaz",
                text = {
                    "Played cards with",
                    "{C:diamonds}Diamond{} suit give",
					"{C:mult}+#1#{} Mult when scored"
                }
            },
            ability_name = "imperialTopaz",
            slug = "imperial",
            ability = {
                extra = {mult = 7}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Imperial Topaz
        local joker_imto = SMODS.Joker:new(
            imto.ability_name,
            imto.slug,
            imto.ability,
            { x = 0, y = 0 },
            imto.loc,
            imto.rarity,
            imto.cost,
            imto.unlocked,
            imto.discovered,
            imto.blueprint_compat,
            imto.eternal_compat,
            nil,
            imto.slug
        )
        joker_imto:register()

        -- Initialize Sprite for Jokers
        local sprite_imto = SMODS.Sprite:new(
            imto.slug,
            flounderJokers.path,
            "j_" .. imto.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_imto:register()

        -- Set local variables for Imperial Topaz
        function joker_imto.loc_def(self)
            return { self.ability.extra.mult}
        end
		-- Calculate
        joker_imto.calculate = function(self, context)
	       if self.ability.name ==  'imperialTopaz' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Diamonds") then
                    return {
                        mult = self.ability.extra.mult,
                        card = self
                    }		
				end
			end
		end
	end
    if config.mozambiqueRuby then
        -- Create Mozambique Ruby
        local moru = {
            loc = {
                name = "Mozambique Ruby",
                text = {
                    "Played cards with",
                    "{C:red}Heart{} suit give",
					"{C:mult}+#1#{} Mult when scored"
                }
            },
            ability_name = "mozambiqueRuby",
            slug = "mozambique",
            ability = {
                extra = {mult = 7}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Mozambique Ruby
        local joker_moru = SMODS.Joker:new(
            moru.ability_name,
            moru.slug,
            moru.ability,
            { x = 0, y = 0 },
            moru.loc,
            moru.rarity,
            moru.cost,
            moru.unlocked,
            moru.discovered,
            moru.blueprint_compat,
            moru.eternal_compat,
            nil,
            moru.slug
        )
        joker_moru:register()

        -- Initialize Sprite for Jokers
        local sprite_moru = SMODS.Sprite:new(
            moru.slug,
            flounderJokers.path,
            "j_" .. moru.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_moru:register()

        -- Set local variables for Mozambique Ruby
        function joker_moru.loc_def(self)
            return { self.ability.extra.mult}
        end
		-- Calculate
        joker_moru.calculate = function(self, context)
	       if self.ability.name ==  'mozambiqueRuby' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Hearts") then
                    return {
                        mult = self.ability.extra.mult,
                        card = self
                    }		
				end
			end
		end
	end
    if config.blackDiamond then
        -- Create Black Diamond
        local bldi = {
            loc = {
                name = "Black Diamond",
                text = {
                    "Played cards with",
                    "{C:spades}Spade{} suit give",
					"{C:mult}+#1#{} Mult when scored"
                }
            },
            ability_name = "blackDiamond",
            slug = "black",
            ability = {
                extra = {mult = 7}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Black Diamond
        local joker_bldi = SMODS.Joker:new(
            bldi.ability_name,
            bldi.slug,
            bldi.ability,
            { x = 0, y = 0 },
            bldi.loc,
            bldi.rarity,
            bldi.cost,
            bldi.unlocked,
            bldi.discovered,
            bldi.blueprint_compat,
            bldi.eternal_compat,
            nil,
            bldi.slug
        )
        joker_bldi:register()

        -- Initialize Sprite for Jokers
        local sprite_bldi = SMODS.Sprite:new(
            bldi.slug,
            flounderJokers.path,
            "j_" .. bldi.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_bldi:register()

        -- Set local variables for Black Diamond
        function joker_bldi.loc_def(self)
            return { self.ability.extra.mult}
        end
		-- Calculate
        joker_bldi.calculate = function(self, context)
	       if self.ability.name ==  'blackDiamond' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Spades") then
                    return {
                        mult = self.ability.extra.mult,
                        card = self
                    }		
				end
			end
		end
	end
    if config.gunsandRoses then
        -- Create Guns and Roses
        local guro = {
            loc = {
                name = "Guns and Roses",
                text = {
                    "Retriggers all",
					"played {C:red}Heart{} cards"
                }
            },
            ability_name = "gunsandRoses",
            slug = "guns",
            ability = {
                extra = {loop_amount = 1}
            },
            rarity = 3,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Guns and Roses
        local joker_guro = SMODS.Joker:new(
            guro.ability_name,
            guro.slug,
            guro.ability,
            { x = 0, y = 0 },
            guro.loc,
            guro.rarity,
            guro.cost,
            guro.unlocked,
            guro.discovered,
            guro.blueprint_compat,
            guro.eternal_compat,
            nil,
            guro.slug
        )
        joker_guro:register()

        -- Initialize Sprite for Jokers
        local sprite_guro = SMODS.Sprite:new(
            guro.slug,
            flounderJokers.path,
            "j_" .. guro.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_guro:register()

        -- Set local variables for Guns and Roses
        function joker_guro.loc_def(card)
            return { card.ability.extra.loop_amount}
        end
		-- Calculate
        joker_guro.calculate = function(self, context)
	        if context.repetition and context.cardarea == G.play then
                if context.other_card and context.other_card:is_suit("Hearts") then
                    return {
                        message = localize('k_again_ex'),
                        repetitions = 1,
                        card = self
                    }		
			    end
			end
	    end
    end
    if config.fishandChips then
        -- Create Fish and Chips
        local fich = {
            loc = {
                name = "Fish and Chips",
                text = {
                    "Retriggers all",
					"played {C:clubs}Club{} cards"
                }
            },
            ability_name = "fishandChips",
            slug = "fish",
            ability = {
                extra = {loop_amount = 1}
            },
            rarity = 3,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Fish and Chips
        local joker_fich = SMODS.Joker:new(
            fich.ability_name,
            fich.slug,
            fich.ability,
            { x = 0, y = 0 },
            fich.loc,
            fich.rarity,
            fich.cost,
            fich.unlocked,
            fich.discovered,
            fich.blueprint_compat,
            fich.eternal_compat,
            nil,
            fich.slug
        )
        joker_fich:register()

        -- Initialize Sprite for Jokers
        local sprite_fich = SMODS.Sprite:new(
            fich.slug,
            flounderJokers.path,
            "j_" .. fich.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_fich:register()

        -- Set local variables for Fish and Chips
        function joker_fich.loc_def(card)
            return { card.ability.extra.loop_amount}
        end
		-- Calculate
        joker_fich.calculate = function(self, context)
	        if context.repetition and context.cardarea == G.play then
                if context.other_card and context.other_card:is_suit("Clubs") then
                    return {
                        message = localize('k_again_ex'),
                        repetitions = 1,
                        card = self
                    }		
			    end
			end
	    end
    end
    if config.saltandPepper then
        -- Create Salt and Pepper
        local sape = {
            loc = {
                name = "Salt and Pepper",
                text = {
                    "Retriggers all",
					"played {C:spades}Spade{} cards"
                }
            },
            ability_name = "saltandPepper",
            slug = "salt",
            ability = {
                extra = {loop_amount = 1}
            },
            rarity = 3,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Salt and Pepper
        local joker_sape = SMODS.Joker:new(
            sape.ability_name,
            sape.slug,
            sape.ability,
            { x = 0, y = 0 },
            sape.loc,
            sape.rarity,
            sape.cost,
            sape.unlocked,
            sape.discovered,
            sape.blueprint_compat,
            sape.eternal_compat,
            nil,
            sape.slug
        )
        joker_sape:register()

        -- Initialize Sprite for Jokers
        local sprite_sape = SMODS.Sprite:new(
            sape.slug,
            flounderJokers.path,
            "j_" .. sape.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_sape:register()

        -- Set local variables for Salt and Pepper
        function joker_sape.loc_def(card)
            return { card.ability.extra.loop_amount}
        end
		-- Calculate
        joker_sape.calculate = function(self, context)
	        if context.repetition and context.cardarea == G.play then
                if context.other_card and context.other_card:is_suit("Spades") then
                    return {
                        message = localize('k_again_ex'),
                        repetitions = 1,
                        card = self
                    }		
			    end
			end
	    end
    end
    if config.macaroniandCheese then
        -- Create Macaroni and Cheese
        local mach = {
            loc = {
                name = "Macaroni and Cheese",
                text = {
                    "Retriggers all",
					"played {C:diamonds}Diamond{} cards"
                }
            },
            ability_name = "macaroniandCheese",
            slug = "macaroni",
            ability = {
                extra = {loop_amount = 1}
            },
            rarity = 3,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Macaroni and Cheese
        local joker_mach = SMODS.Joker:new(
            mach.ability_name,
            mach.slug,
            mach.ability,
            { x = 0, y = 0 },
            mach.loc,
            mach.rarity,
            mach.cost,
            mach.unlocked,
            mach.discovered,
            mach.blueprint_compat,
            mach.eternal_compat,
            nil,
            mach.slug
        )
        joker_mach:register()

        -- Initialize Macaroni and Cheese
        local sprite_mach = SMODS.Sprite:new(
            mach.slug,
            flounderJokers.path,
            "j_" .. mach.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_mach:register()

        -- Set local variables for Macaroni and Cheese
        function joker_mach.loc_def(card)
            return { card.ability.extra.loop_amount}
        end
		-- Calculate
        joker_mach.calculate = function(self, context)
	        if context.repetition and context.cardarea == G.play then
                if context.other_card and context.other_card:is_suit("Diamonds") then
                    return {
                        message = localize('k_again_ex'),
                        repetitions = 1,
                        card = self
                    }		
			    end
			end
	    end
    end
    if config.theRobber then
	    -- Create The Robber
        local thro = {
            loc = {
                name = "The Robber",
                text = {
                    "All {C:spades}Spade{} suit cards have",
					"{C:green}#2# in #1#{} chance to",
                    "become {C:attention}Steel{} cards",
                    "when played"
                }
            },
            ability_name = "theRobber",
            slug = "robberh",
            ability = {
                extra = {odds = 10}
            },
            rarity = 3,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize The Robber
        local joker_thro = SMODS.Joker:new(
            thro.ability_name,
            thro.slug,
            thro.ability,
            { x = 0, y = 0 },
            thro.loc,
            thro.rarity,
            thro.cost,
            thro.unlocked,
            thro.discovered,
            thro.blueprint_compat,
            thro.eternal_compat,
            nil,
            thro.slug
        )
        joker_thro:register()

        -- Initialize Sprite for Jokers
        local sprite_thro = SMODS.Sprite:new(
            thro.slug,
            flounderJokers.path,
            "j_" .. thro.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_thro:register()

        -- Set local variables for The Robber
        function joker_thro.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1)}
        end
        -- Calculate
        joker_thro.calculate = function(self, context)
	       if self.ability.name ==  'theRobber' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Spades") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then				
                        if FJ_EFFECT then FJ_EFFECT(self) end
                        for k, v in ipairs(context.full_hand) do
                            if v:is_suit("Spades") then
                                v:set_ability(G.P_CENTERS.m_steel, nil, true)
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        v:juice_up()
                                        return true
                                    end
						        }))        
                            end
                        end
	                end
		        end
	        end
        end
	end
    if config.hungrySorcerer then
	    -- Create Hungry Sorcerer
        local huso = {
            loc = {
                name = "Hungry Sorcerer",
                text = {
                    "All {C:clubs}Club{} suit cards have",
					"{C:green}#2# in #1#{} chance to",
                    "become {C:attention}Lucky{} cards",
                    "when played"
                }
            },
            ability_name = "hungrySorcerer",
            slug = "hungryso",
            ability = {
                extra = {odds = 10}
            },
            rarity = 3,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Hungry Sorcerer
        local joker_huso = SMODS.Joker:new(
            huso.ability_name,
            huso.slug,
            huso.ability,
            { x = 0, y = 0 },
            huso.loc,
            huso.rarity,
            huso.cost,
            huso.unlocked,
            huso.discovered,
            huso.blueprint_compat,
            huso.eternal_compat,
            nil,
            huso.slug
        )
        joker_huso:register()

        -- Initialize Sprite for Jokers
        local sprite_huso = SMODS.Sprite:new(
            huso.slug,
            flounderJokers.path,
            "j_" .. huso.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_huso:register()

        -- Set local variables for Hungry Sorcerer
        function joker_huso.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1)}
        end
        -- Calculate
        joker_huso.calculate = function(self, context)
	       if self.ability.name ==  'hungrySorcerer' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Clubs") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then				
                        if FJ_EFFECT then FJ_EFFECT(self) end
                        for k, v in ipairs(context.full_hand) do
                            if v:is_suit("Clubs") then
                                v:set_ability(G.P_CENTERS.m_lucky, nil, true)
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                       v:juice_up()
                                        return true
                                    end
						        }))        
                            end
                        end
	                end
		        end
	        end
        end
	end
	if config.glassBlower then
	    -- Create Glass Blower
        local glbl = {
            loc = {
                name = "Glass Blower",
                text = {
                    "All {C:diamonds}Diamond{} suit cards have",
					"{C:green}#2# in #1#{} chance to",
                    "become {C:attention}glass{} cards",
                    "when played"
                }
            },
            ability_name = "glassBlower",
            slug = "glassb",
            ability = {
                extra = {odds = 10}
            },
            rarity = 3,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Glass Blower
        local joker_glbl = SMODS.Joker:new(
            glbl.ability_name,
            glbl.slug,
            glbl.ability,
            { x = 0, y = 0 },
            glbl.loc,
            glbl.rarity,
            glbl.cost,
            glbl.unlocked,
            glbl.discovered,
            glbl.blueprint_compat,
            glbl.eternal_compat,
            nil,
            glbl.slug
        )
        joker_glbl:register()

        -- Initialize Sprite for Jokers
        local sprite_glbl = SMODS.Sprite:new(
            glbl.slug,
            flounderJokers.path,
            "j_" .. glbl.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_glbl:register()

        -- Set local variables for Glass Blower
        function joker_glbl.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1)}
        end
        -- Calculate
        joker_glbl.calculate = function(self, context)
	       if self.ability.name ==  'glassBlower' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Diamonds") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then				
                        if FJ_EFFECT then FJ_EFFECT(self) end
                        for k, v in ipairs(context.full_hand) do
                            if v:is_suit("Diamonds") then
                                v:set_ability(G.P_CENTERS.m_glass, nil, true)
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                       v:juice_up()
                                        return true
                                    end
						        }))        
                            end
                        end
	                end
		        end
	        end
        end
	end
	if config.bornWild then
	    -- Create Born Wild
        local bowi = {
            loc = {
                name = "Born Wild",
                text = {
                    "All {C:hearts}Heart{} suit cards have",
					"{C:green}#2# in #1#{} chance to",
                    "become {C:attention}Wild{} cards",
                    "when played"
                }
            },
            ability_name = "bornWild",
            slug = "bornw",
            ability = {
                extra = {odds = 10}
            },
            rarity = 3,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Born Wild
        local joker_bowi = SMODS.Joker:new(
            bowi.ability_name,
            bowi.slug,
            bowi.ability,
            { x = 0, y = 0 },
            bowi.loc,
            bowi.rarity,
            bowi.cost,
            bowi.unlocked,
            bowi.discovered,
            bowi.blueprint_compat,
            bowi.eternal_compat,
            nil,
            bowi.slug
        )
        joker_bowi:register()

        -- Initialize Sprite for Jokers
        local sprite_bowi = SMODS.Sprite:new(
            bowi.slug,
            flounderJokers.path,
            "j_" .. bowi.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_bowi:register()

        -- Set local variables for Born Wild
        function joker_bowi.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1)}
        end
        -- Calculate
        joker_bowi.calculate = function(self, context)
	       if self.ability.name ==  'bornWild' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Hearts") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then
                        if FJ_EFFECT then FJ_EFFECT(self) end
					    for k, v in ipairs(context.full_hand) do
                            if v:is_suit("Hearts") then
                               v:set_ability(G.P_CENTERS.m_wild, nil, true)
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                       v:juice_up()
                                        return true
							        end
                                }))
	                        end
		                end
	                end
                end
	        end
	    end
	end
	if config.overtheRainbow then
	    -- Create Over the Rainbow
        local ovra = {
            loc = {
                name = "Over the Rainbow",
                text = {
                    "Played hands that contain {C:attention}Flush{} have",
					"{C:green}#2# in #1#{} chance to",
                    "become {C:colourcard}Polychrome{} cards",
                    "when played"
                }
            },
            ability_name = "overtheRainbow",
            slug = "overt",
            ability = {
                extra = {odds = 20}
            },
            rarity = 4,
            cost = 12,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Over the Rainbow
        local joker_ovra = SMODS.Joker:new(
            ovra.ability_name,
            ovra.slug,
            ovra.ability,
            { x = 0, y = 0 },
            ovra.loc,
            ovra.rarity,
            ovra.cost,
            ovra.unlocked,
            ovra.discovered,
            ovra.blueprint_compat,
            ovra.eternal_compat,
            nil,
            ovra.slug
        )
        joker_ovra:register()

        -- Initialize Sprite for Jokers
        local sprite_ovra = SMODS.Sprite:new(
            ovra.slug,
            flounderJokers.path,
            "j_" .. ovra.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_ovra:register()

        -- Set local variables for Over the Rainbow
        function joker_ovra.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1)}
        end
        -- Calculate
        joker_ovra.calculate = function(self, context)
	       if self.ability.name ==  'overtheRainbow' then
		        if context.cardarea == G.play and not context.repetition then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then
                        if FJ_EFFECT then FJ_EFFECT(self) end
                        if next(get_flush(context.full_hand)) then
					        for k, v in ipairs(context.full_hand) do
                                v:set_edition({polychrome = true}, true, true)
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        v:juice_up()
                                        return true
						        end
						    }))
                            end
	                    end
		            end
	            end
            end
	    end
	end
    if mod_loaded('CodexArcanum') and config.witchDoctor then
	
	    -- Create Witch Doctor
        local wido = {
            loc = {
                name = "Witch Doctor",
                text = {
                    "All {C:crowns}Crown{} suit cards have",
					"{C:green}#2# in #1#{} chance to",  
                    "Create an {C:alchemical}Alchemical{} card when played",
                }
            },
            ability_name = "witchDoctor",
            slug = "witchdo",
            ability = {
                extra = {odds = 10, used = false}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Witch Doctor
        local joker_wido = SMODS.Joker:new(
            wido.ability_name,
            wido.slug,
            wido.ability,
            { x = 0, y = 0 },
            wido.loc,
            wido.rarity,
            wido.cost,
            wido.unlocked,
            wido.discovered,
            wido.blueprint_compat,
            wido.eternal_compat,
            nil,
            wido.slug
        )
        joker_wido:register()

        -- Initialize Sprite for Jokers
        local sprite_wido = SMODS.Sprite:new(
            wido.slug,
            flounderJokers.path,
            "j_" .. wido.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_wido:register()

        -- Set local variables for Witch Doctor
        function joker_wido.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1),self.ability.extra.used}
        end
        -- Calculate
        joker_wido.calculate = function(self, context)
	       if self.ability.name ==  'witchDoctor' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Crowns") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then				
                        if FJ_EFFECT then FJ_EFFECT(self) end
                        self.ability.extra.used = false
						if not context.blueprint and #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                            add_random_alchemical(self)
                            card_eval_status_text(self, 'extra', nil, nil, nil, {message = localize('p_plus_alchemical'), colour = G.C.SECONDARY_SET.Alchemy})
                        end
					end
				end
            end
            if context.using_consumeable and not context.consumeable.config.in_booster then
                if context.consumeable.ability.set == 'Alchemical' and self.ability.extra.used == false then
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = (function()
                            G.E_MANAGER:add_event(Event({
                                func = function() 
                                    local card = create_card('Tarot',G.consumeables, nil, nil, nil, nil, nil, 'car')
                                    card:set_edition({negative = true})
                                    card:add_to_deck()
                                    G.consumeables:emplace(card)
                                    G.GAME.consumeable_buffer = 0
                                    return true
                                end}))   
                                card_eval_status_text(context.blueprint_card or self, 'extra', nil, nil, nil, {message = localize('k_plus_tarot'), colour = G.C.PURPLE})                       
                            return true
                        end)}))
                    self.ability.extra.used = true
                end
            end
        end
    end
	if config.palmReader then
	    -- Create Palm Reader
        local pare = {
            loc = {
                name = "Palm Reader",
                text = {
                    "All {C:clubs}Club{} suit cards have",
					"{C:green}#2# in #1#{} chance to",  
                    "Create an {C:purple}Tarot{} card when played",
                }
            },
            ability_name = "palmReader",
            slug = "palmr",
            ability = {
                extra = {odds = 5}
            },
            rarity = 2,
            cost = 12,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Palm Reader
        local joker_pare = SMODS.Joker:new(
            pare.ability_name,
            pare.slug,
            pare.ability,
            { x = 0, y = 0 },
            pare.loc,
            pare.rarity,
            pare.cost,
            pare.unlocked,
            pare.discovered,
            pare.blueprint_compat,
            pare.eternal_compat,
            nil,
            pare.slug
        )
        joker_pare:register()

        -- Initialize Sprite for Jokers
        local sprite_pare = SMODS.Sprite:new(
            pare.slug,
            flounderJokers.path,
            "j_" .. pare.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_pare:register()

        -- Set local variables for Palm Reader
        function joker_pare.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1)}
        end
        -- Calculate
        joker_pare.calculate = function(self, context)
	       if self.ability.name ==  'palmReader' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Clubs") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then
                        if FJ_EFFECT then FJ_EFFECT(self) end
					    if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                            G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                            G.E_MANAGER:add_event(Event({
                                trigger = 'before',
                                delay = 0.0,
                                func = (function()
                                        local card = create_card('Tarot',G.consumeables, nil, nil, nil, nil, nil, '8ba')
                                        card:add_to_deck()
                                        G.consumeables:emplace(card)
                                        G.GAME.consumeable_buffer = 0
                                    return true
                                end)}))
                            card_eval_status_text(self, 'extra', nil, nil, nil, {message = localize('k_plus_tarot'), colour = G.C.PURPLE})
                        end
                        return {
                            card = self
                        }
                    end
                end
            end
        end
	end
	if mod_loaded('MoreFluff') and config.painTer then
	    -- Initialize Painter
        local pate = {
            loc = {
                name = "Painter",
                text = {
                    "All {C:diamonds}Diamond{} suit cards have",
					"{C:green}#2# in #1#{} chance to",  
                    "Create an {C:colourcard}Colour{} card when played",
                }
            },
            ability_name = "painTer",
            slug = "paint",
            ability = {
                extra = {odds = 5}
            },
            rarity = 2,
            cost = 12,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Painter
        local joker_pate = SMODS.Joker:new(
            pate.ability_name,
            pate.slug,
            pate.ability,
            { x = 0, y = 0 },
            pate.loc,
            pate.rarity,
            pate.cost,
            pate.unlocked,
            pate.discovered,
            pate.blueprint_compat,
            pate.eternal_compat,
            nil,
            pate.slug
        )
        joker_pate:register()

        -- Initialize Sprite for Jokers
        local sprite_pate = SMODS.Sprite:new(
            pate.slug,
            flounderJokers.path,
            "j_" .. pate.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_pate:register()

        -- Set local variables for Painter
        function joker_pate.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1)}
        end
        -- Calculate
        joker_pate.calculate = function(self, context)
	       if self.ability.name ==  'painTer' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Diamonds") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then
                        if FJ_EFFECT then FJ_EFFECT(self) end
					    if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                            G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                            G.E_MANAGER:add_event(Event({
                                trigger = 'before',
                                delay = 0.0,
                                func = (function()
                                        local card = create_card('Colour',G.consumeables, nil, nil, nil, nil, nil, 'cli')
                                        card:add_to_deck()
                                        G.consumeables:emplace(card)
                                        G.GAME.consumeable_buffer = 0
                                    return true
                                end)}))
                            card_eval_status_text(self, 'extra', nil, nil, nil, {message = localize('k_plus_tarot'), colour = G.C.PURPLE})
                        end
                        return {
                            card = self
                        }
                    end
                end
            end
        end
	end
    if mod_loaded('Reverie') and config.diRector then
	    -- Initialize Director
        local dire = {
            loc = {
                name = "Director",
                text = {
                    "All {C:spades}Spade{} suit cards have",
					"{C:green}#2# in #1#{} chance to",  
                    "Create a {C:cine}Cinema{} card when played",
                }
            },
            ability_name = "diRector",
            slug = "direc",
            ability = {
                extra = {odds = 5}
            },
            rarity = 2,
            cost = 12,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Palm Reader
        local joker_dire = SMODS.Joker:new(
            dire.ability_name,
            dire.slug,
            dire.ability,
            { x = 0, y = 0 },
            dire.loc,
            dire.rarity,
            dire.cost,
            dire.unlocked,
            dire.discovered,
            dire.blueprint_compat,
            dire.eternal_compat,
            nil,
            dire.slug
        )
        joker_dire:register()

        -- Initialize Sprite for Jokers
        local sprite_dire = SMODS.Sprite:new(
            dire.slug,
            flounderJokers.path,
            "j_" .. dire.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_dire:register()

        -- Set local variables for Palm Reader
        function joker_dire.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1)}
        end
        -- Calculate
        joker_dire.calculate = function(self, context)
	       if self.ability.name ==  'diRector' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Spades") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then
                        if FJ_EFFECT then FJ_EFFECT(self) end
					    if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                            G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                            G.E_MANAGER:add_event(Event({
                                trigger = 'before',
                                delay = 0.0,
                                func = (function()
                                        local card = create_card('Cine',G.consumeables, nil, nil, nil, nil, nil, '8ba')
                                        card:add_to_deck()
                                        G.consumeables:emplace(card)
                                        G.GAME.consumeable_buffer = 0
                                    return true
                                end)}))
                            card_eval_status_text(self, 'extra', nil, nil, nil, {message = localize('k_plus_tarot'), colour = G.C.PURPLE})
                        end
                        return {
                            card = self
                        }
                    end
                end
            end
        end
	end
	if config.orbit then
	    -- Initialize Orbit
        local orit = {
            loc = {
                name = "Orbit",
                text = {
                    "All {C:hearts}Heart{} suit cards have",
					"{C:green}#2# in #1#{} chance to",  
                    "Create an {C:planet}Planet{} card when played",
                }
            },
            ability_name = "orbit",
            slug = "orb",
            ability = {
                extra = {odds = 5}
            },
            rarity = 2,
            cost = 12,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Palm Reader
        local joker_orit = SMODS.Joker:new(
            orit.ability_name,
            orit.slug,
            orit.ability,
            { x = 0, y = 0 },
            orit.loc,
            orit.rarity,
            orit.cost,
            orit.unlocked,
            orit.discovered,
            orit.blueprint_compat,
            orit.eternal_compat,
            nil,
            orit.slug
        )
        joker_orit:register()

        -- Initialize Sprite for Jokers
        local sprite_orit = SMODS.Sprite:new(
            orit.slug,
            flounderJokers.path,
            "j_" .. orit.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_orit:register()

        -- Set local variables for Palm Reader
        function joker_orit.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1)}
        end
        -- Calculate
        joker_orit.calculate = function(self, context)
	       if self.ability.name ==  'orbit' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Hearts") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then
                        if FJ_EFFECT then FJ_EFFECT(self) end
					    if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                            G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                            G.E_MANAGER:add_event(Event({
                                trigger = 'before',
                                delay = 0.0,
                                func = (function()
                                    if G.GAME.last_hand_played then
                                        local _planet = 0
                                        for k, v in pairs(G.P_CENTER_POOLS.Planet) do
                                            if v.config.hand_type == G.GAME.last_hand_played then
                                                _planet = v.key
                                            end
                                        end
                                        local card = create_card('Planet', G.consumeables, nil, nil, nil, nil, _planet, '8ba')
                                        card:add_to_deck()
                                        G.consumeables:emplace(card)
                                        G.GAME.consumeable_buffer = 0
                                    end
                                    return true
                                end)}))
                            card_eval_status_text(self, 'extra', nil, nil, nil, {message = localize('k_plus_planet'), colour = G.C.SECONDARY_SET.Planet})
                        end
                        return {
                            card = self
                        }
                    end
				end
			end
		end
	end
	
	----- MusicSuit collab !!!!! -----------------
	----------------------------------------------
	
	if mod_loaded('MusicalSuit') and config.crystalizedStone then
	
	    -- Create Crystalized Stone
        local cyst = {
            loc = {
                name = "Crystalized Stone",
                text = {
                    "{C:green}#2# in #1#{} chance for",
                    "played cards with {C:notes}Note{} suit",
					"to give {X:mult,C:white}X#3#{} mult when scored"
                }
            },
            ability_name = "crystalizedStone",
            slug = "crystalized",
            ability = {
                extra = {odds = 2, Xmult = 1.5}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Crystalized Stone
        local joker_cyst = SMODS.Joker:new(
            cyst.ability_name,
            cyst.slug,
            cyst.ability,
            { x = 0, y = 0 },
            cyst.loc,
            cyst.rarity,
            cyst.cost,
            cyst.unlocked,
            cyst.discovered,
            cyst.blueprint_compat,
            cyst.eternal_compat,
            nil,
            cyst.slug
        )
        joker_cyst:register()

        -- Initialize Sprite for Jokers
        local sprite_cyst = SMODS.Sprite:new(
            cyst.slug,
            flounderJokers.path,
            "j_" .. cyst.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_cyst:register()

        -- Set local variables for Crystalized Stone
        function joker_cyst.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1),self.ability.extra.Xmult}
        end
        -- Calculate
        joker_cyst.calculate = function(self, context)
	       if self.ability.name ==  'crystalizedStone' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Notes") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then
                        if FJ_EFFECT then FJ_EFFECT(self) end
                        return {
                            x_mult = self.ability.extra.Xmult,
                            card = self
                        }
                    end
                end
	        end
		end
	end
    if mod_loaded('MusicalSuit') and config.crystalMagazine then
        -- Create Crystal Magazine
        local crma = {
            loc = {
                name = "Crystal Magazine",
                text = {
                    "Played cards with",
                    "{C:notes}Note{} suit give",
					"{C:chips}+#1#{} Chips when scored"
                }
            },
            ability_name = "crystalMagazine",
            slug = "crystalm",
            ability = {
                extra = {chips = 50}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Crystal Magazine
        local joker_crma = SMODS.Joker:new(
            crma.ability_name,
            crma.slug,
            crma.ability,
            { x = 0, y = 0 },
            crma.loc,
            crma.rarity,
            crma.cost,
            crma.unlocked,
            crma.discovered,
            crma.blueprint_compat,
            crma.eternal_compat,
            nil,
            crma.slug
        )
        joker_crma:register()

        -- Initialize Sprite for Jokers
        local sprite_crma = SMODS.Sprite:new(
            crma.slug,
            flounderJokers.path,
            "j_" .. crma.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_crma:register()

        -- Set local variables for Crystal Magazine
        function joker_crma.loc_def(self)
            return { self.ability.extra.chips}
        end
		-- Calculate
        joker_crma.calculate = function(self, context)
	       if self.ability.name ==  'crystalMagazine' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Notes") then
                    return {
                        chips = self.ability.extra.chips,
                        card = self
                    }		
				end
			end
		end
	end
	if mod_loaded('MusicalSuit') and config.pinkPanther then
        -- Create Pink Panther
        local pipa = {
            loc = {
                name = "Pink Panther",
                text = {
                    "Played cards with",
                    "{C:notes}Note{} suit give",
					"{C:mult}+#1#{} Mult when scored"
                }
            },
            ability_name = "pinkPanther",
            slug = "pinkpa",
            ability = {
                extra = {mult = 7}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Pink Panther
        local joker_pipa = SMODS.Joker:new(
            pipa.ability_name,
            pipa.slug,
            pipa.ability,
            { x = 0, y = 0 },
            pipa.loc,
            pipa.rarity,
            pipa.cost,
            pipa.unlocked,
            pipa.discovered,
            pipa.blueprint_compat,
            pipa.eternal_compat,
            nil,
            pipa.slug
        )
        joker_pipa:register()

        -- Initialize Sprite for Jokers
        local sprite_pipa = SMODS.Sprite:new(
            pipa.slug,
            flounderJokers.path,
            "j_" .. pipa.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_pipa:register()

        -- Set local variables for Pink Panther
        function joker_pipa.loc_def(self)
            return { self.ability.extra.mult}
        end
		-- Calculate
        joker_pipa.calculate = function(self, context)
	       if self.ability.name ==  'pinkPanther' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Notes") then
                    return {
                        mult = self.ability.extra.mult,
                        card = self
                    }		
				end
			end
		end
	end    
    if mod_loaded('MusicalSuit') and config.loveGem then
        -- Create Love Gem
        local loge = {
            loc = {
                name = "Love Gem",
                text = {
                    "Played cards with",
                    "{C:notes}Note{} suit give",
					"{C:money}$#1#{} when scored"
                }
            },
            ability_name = "loveGem",
            slug = "lovege",
            ability = {
                extra = {money = 1}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Love Gem
        local joker_loge = SMODS.Joker:new(
            loge.ability_name,
            loge.slug,
            loge.ability,
            { x = 0, y = 0 },
            loge.loc,
            loge.rarity,
            loge.cost,
            loge.unlocked,
            loge.discovered,
            loge.blueprint_compat,
            loge.eternal_compat,
            nil,
            loge.slug
        )
        joker_loge:register()

        -- Initialize Sprite for Jokers
        local sprite_loge = SMODS.Sprite:new(
            loge.slug,
            flounderJokers.path,
            "j_" .. loge.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_loge:register()

        -- Set local variables for Love Gem
        function joker_loge.loc_def(self)
            return { self.ability.extra.money}
        end
		-- Calculate
        joker_loge.calculate = function(self, context)
	       if self.ability.name ==  'loveGem' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Notes") then
                    G.GAME.dollar_buffer = (G.GAME.dollar_buffer or 0) + self.ability.extra.money
					G.E_MANAGER:add_event(Event({func = (function() G.GAME.dollar_buffer = 0; return true end)}))
                    return {
                        dollars = self.ability.extra.money,
                        card = self
                    }		
				end
			end
		end
	end
    if mod_loaded('MusicalSuit') and config.rhythmandBlues then
        -- Create Rhythm and Blues
        local rhbl = {
            loc = {
                name = "Rhythm and Blues",
                text = {
                    "Retriggers all",
					"played {C:notes}Note{} cards"
                }
            },
            ability_name = "rhythmandBlues",
            slug = "rhythm",
            ability = {
                extra = {loop_amount = 1}
            },
            rarity = 3,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Rhythm and Blues
        local joker_rhbl = SMODS.Joker:new(
            rhbl.ability_name,
            rhbl.slug,
            rhbl.ability,
            { x = 0, y = 0 },
            rhbl.loc,
            rhbl.rarity,
            rhbl.cost,
            rhbl.unlocked,
            rhbl.discovered,
            rhbl.blueprint_compat,
            rhbl.eternal_compat,
            nil,
            rhbl.slug
        )
        joker_rhbl:register()

        -- Initialize Sprite for Jokers
        local sprite_rhbl = SMODS.Sprite:new(
            rhbl.slug,
            flounderJokers.path,
            "j_" .. rhbl.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_rhbl:register()

        -- Set local variables for Rhythm and Blues
        function joker_rhbl.loc_def(card)
            return { card.ability.extra.loop_amount}
        end
		-- Calculate
        joker_rhbl.calculate = function(self, context)
	        if context.repetition and context.cardarea == G.play then
                if context.other_card and context.other_card:is_suit("Notes") then
                    return {
                        message = localize('k_again_ex'),
                        repetitions = 1,
                        card = self
                    }		
			    end
			end
	    end
    end
	if mod_loaded('MusicalSuit') and config.enchancedSediment then
	    -- Create Enhanced Sediment
        local ense = {
            loc = {
                name = "Enhanced Sediment",
                text = {
                    "All {C:notes}Note{} suit cards have",
					"{C:green}#2# in #1#{} chance to",
                    "become {C:attention}stone{} cards",
                    "when played"
                }
            },
            ability_name = "enchancedSediment",
            slug = "enhanceds",
            ability = {
                extra = {odds = 10}
            },
            rarity = 3,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Enhanced Sediment
        local joker_ense = SMODS.Joker:new(
            ense.ability_name,
            ense.slug,
            ense.ability,
            { x = 0, y = 0 },
            ense.loc,
            ense.rarity,
            ense.cost,
            ense.unlocked,
            ense.discovered,
            ense.blueprint_compat,
            ense.eternal_compat,
            nil,
            ense.slug
        )
        joker_ense:register()

        -- Initialize Sprite for Jokers
        local sprite_ense = SMODS.Sprite:new(
            ense.slug,
            flounderJokers.path,
            "j_" .. ense.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_ense:register()

        -- Set local variables for Enhanced Sediment
        function joker_ense.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1)}
        end
        -- Calculate
        joker_ense.calculate = function(self, context)
	       if self.ability.name ==  'enchancedSediment' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Notes") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then				
                        if FJ_EFFECT then FJ_EFFECT(self) end
                        for k, v in ipairs(context.full_hand) do
                            if v:is_suit("Notes") then
                                v:set_ability(G.P_CENTERS.m_stone, nil, true)
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                       v:juice_up()
                                        return true
                                    end
						        }))        
                            end
                        end
	                end
		        end
	        end
        end
	end
	
	----- CrownSuit collab !!!!! -----------------
	----------------------------------------------
	
	if mod_loaded('CrownsSuit') and config.luxuryStone then
	
	    -- Create Luxury Stone
        local lxst = {
            loc = {
                name = "Luxury Stone",
                text = {
                    "{C:green}#2# in #1#{} chance for",
                    "played cards with {C:crowns}Crown{} suit",
					"to give {X:mult,C:white}X#3#{} mult when scored"
                }
            },
            ability_name = "luxuryStone",
            slug = "luxury",
            ability = {
                extra = {odds = 2, Xmult = 1.5}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Luxury Stone
        local joker_lxst = SMODS.Joker:new(
            lxst.ability_name,
            lxst.slug,
            lxst.ability,
            { x = 0, y = 0 },
            lxst.loc,
            lxst.rarity,
            lxst.cost,
            lxst.unlocked,
            lxst.discovered,
            lxst.blueprint_compat,
            lxst.eternal_compat,
            nil,
            lxst.slug
        )
        joker_lxst:register()

        -- Initialize Sprite for Jokers
        local sprite_lxst = SMODS.Sprite:new(
            lxst.slug,
            flounderJokers.path,
            "j_" .. lxst.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_lxst:register()

        -- Set local variables for Luxury Stone
        function joker_lxst.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1),self.ability.extra.Xmult}
        end
        -- Calculate
        joker_lxst.calculate = function(self, context)
	       if self.ability.name ==  'luxuryStone' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Crowns") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then
                        if FJ_EFFECT then FJ_EFFECT(self) end
                        return {
                            x_mult = self.ability.extra.Xmult,
                            card = self
                        }
                    end
                end
	        end
		end
	end
    if mod_loaded('CrownsSuit') and config.sunGun then
        -- Create Sun Gun
        local sugu = {
            loc = {
                name = "Sun Gun",
                text = {
                    "Played cards with",
                    "{C:crowns}Crown{} suit give",
					"{C:chips}+#1#{} Chips when scored"
                }
            },
            ability_name = "sunGun",
            slug = "sung",
            ability = {
                extra = {chips = 50}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Sun Gun
        local joker_sugu = SMODS.Joker:new(
            sugu.ability_name,
            sugu.slug,
            sugu.ability,
            { x = 0, y = 0 },
            sugu.loc,
            sugu.rarity,
            sugu.cost,
            sugu.unlocked,
            sugu.discovered,
            sugu.blueprint_compat,
            sugu.eternal_compat,
            nil,
            sugu.slug
        )
        joker_sugu:register()

        -- Initialize Sprite for Jokers
        local sprite_sugu = SMODS.Sprite:new(
            sugu.slug,
            flounderJokers.path,
            "j_" .. sugu.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_sugu:register()

        -- Set local variables for Sun Gun
        function joker_sugu.loc_def(self)
            return { self.ability.extra.chips}
        end
		-- Calculate
        joker_sugu.calculate = function(self, context)
	       if self.ability.name ==  'sunGun' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Crowns") then
                    return {
                        chips = self.ability.extra.chips,
                        card = self
                    }		
				end
			end
		end
	end
    if mod_loaded('CrownsSuit') and config.holyGem then
	    -- Create Holy Gem
        local hoge = {
            loc = {
                name = "Holy Gem",
                text = {
                    "Played cards with",
                    "{C:crowns}Crown{} suit give",
					"{C:money}$#1#{} when scored"
                }
            },
            ability_name = "holyGem",
            slug = "holyge",
            ability = {
                extra = {money = 1}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Holy Gem
        local joker_hoge = SMODS.Joker:new(
            hoge.ability_name,
            hoge.slug,
            hoge.ability,
            { x = 0, y = 0 },
            hoge.loc,
            hoge.rarity,
            hoge.cost,
            hoge.unlocked,
            hoge.discovered,
            hoge.blueprint_compat,
            hoge.eternal_compat,
            nil,
            hoge.slug
        )
        joker_hoge:register()

        -- Initialize Sprite for Jokers
        local sprite_hoge = SMODS.Sprite:new(
            hoge.slug,
            flounderJokers.path,
            "j_" .. hoge.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_hoge:register()

        -- Set local variables for Holy Gem
        function joker_hoge.loc_def(self)
            return { self.ability.extra.money}
        end
		-- Calculate
        joker_hoge.calculate = function(self, context)
	       if self.ability.name ==  'holyGem' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Crowns") then
                    G.GAME.dollar_buffer = (G.GAME.dollar_buffer or 0) + self.ability.extra.money
					G.E_MANAGER:add_event(Event({func = (function() G.GAME.dollar_buffer = 0; return true end)}))
                    return {
                        dollars = self.ability.extra.money,
                        card = self
                    }		
				end
			end
		end
	end
	if mod_loaded('CrownsSuit') and config.goldBar then
        -- Create Gold Bar
        local goba = {
            loc = {
                name = "Gold Bar",
                text = {
                    "Played cards with",
                    "{C:crowns}crown{} suit give",
					"{C:mult}+#1#{} Mult when scored"
                }
            },
            ability_name = "goldBar",
            slug = "goldba",
            ability = {
                extra = {mult = 7}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Gold Bar
        local joker_goba = SMODS.Joker:new(
            goba.ability_name,
            goba.slug,
            goba.ability,
            { x = 0, y = 0 },
            goba.loc,
            goba.rarity,
            goba.cost,
            goba.unlocked,
            goba.discovered,
            goba.blueprint_compat,
            goba.eternal_compat,
            nil,
            goba.slug
        )
        joker_goba:register()

        -- Initialize Sprite for Jokers
        local sprite_goba = SMODS.Sprite:new(
            goba.slug,
            flounderJokers.path,
            "j_" .. goba.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_goba:register()

        -- Set local variables for Gold Bar
        function joker_goba.loc_def(self)
            return { self.ability.extra.mult}
        end
		-- Calculate
        joker_goba.calculate = function(self, context)
	       if self.ability.name ==  'goldBar' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Crowns") then
                    return {
                        mult = self.ability.extra.mult,
                        card = self
                    }		
				end
			end
		end
	end
	if mod_loaded('CrownsSuit') and config.breadandButter then
        -- Create Bread and Butter
        local brbu = {
            loc = {
                name = "Bread and Butter",
                text = {
                    "Retriggers all",
					"played {C:crowns}Crown{} cards"
                }
            },
            ability_name = "breadandButter",
            slug = "bread",
            ability = {
                extra = {loop_amount = 1}
            },
            rarity = 3,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Bread and Butter
        local joker_brbu = SMODS.Joker:new(
            brbu.ability_name,
            brbu.slug,
            brbu.ability,
            { x = 0, y = 0 },
            brbu.loc,
            brbu.rarity,
            brbu.cost,
            brbu.unlocked,
            brbu.discovered,
            brbu.blueprint_compat,
            brbu.eternal_compat,
            nil,
            brbu.slug
        )
        joker_brbu:register()

        -- Initialize Sprite for Jokers
        local sprite_brbu = SMODS.Sprite:new(
            brbu.slug,
            flounderJokers.path,
            "j_" .. brbu.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_brbu:register()

        -- Set local variables for Bread and Butter
        function joker_brbu.loc_def(card)
            return { card.ability.extra.loop_amount}
        end
		-- Calculate
        joker_brbu.calculate = function(self, context)
	        if context.repetition and context.cardarea == G.play then
                if context.other_card and context.other_card:is_suit("Crowns") then
                    return {
                        message = localize('k_again_ex'),
                        repetitions = 1,
                        card = self
                    }		
			    end
			end
	    end
    end
    if mod_loaded('CrownsSuit') and config.kingsWrath then
	
	    -- Create Kings Wrath
        local kiwr = {
            loc = {
                name = "Kings Wrath",
                text = {
                    "All {C:crowns}Crown{} suit cards have",
					"{C:green}#2# in #1#{} chance to",  
                    "become {C:attention}Gold{} cards",
                    "when played"
                }
            },
            ability_name = "kingsWrath",
            slug = "kingsw",
            ability = {
                extra = {odds = 10}
            },
            rarity = 3,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Kings Wrath
        local joker_kiwr = SMODS.Joker:new(
            kiwr.ability_name,
            kiwr.slug,
            kiwr.ability,
            { x = 0, y = 0 },
            kiwr.loc,
            kiwr.rarity,
            kiwr.cost,
            kiwr.unlocked,
            kiwr.discovered,
            kiwr.blueprint_compat,
            kiwr.eternal_compat,
            nil,
            kiwr.slug
        )
        joker_kiwr:register()

        -- Initialize Sprite for Jokers
        local sprite_kiwr = SMODS.Sprite:new(
            kiwr.slug,
            flounderJokers.path,
            "j_" .. kiwr.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_kiwr:register()

        -- Set local variables for Kings Wrath
        function joker_kiwr.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1)}
        end
        -- Calculate
        joker_kiwr.calculate = function(self, context)
	       if self.ability.name ==  'kingsWrath' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Crowns") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then				
                        if FJ_EFFECT then FJ_EFFECT(self) end
                        for k, v in ipairs(context.full_hand) do
                            if v:is_suit("Crowns") then
                                v:set_ability(G.P_CENTERS.m_gold, nil, true)
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        v:juice_up()
                                        return true
                                    end
						        }))        
                            end
                        end
	                end
		        end
	        end
        end
    end
    
----- SixSuit collab !!!!! -------------------
----------------------------------------------

    if mod_loaded('SixSuit') and config.moonStone then
	
	    -- Create Moon Stone
        local most = {
            loc = {
                name = "Moon Stone",
                text = {
                    "{C:green}#2# in #1#{} chance for",
                    "played cards with {C:moons}Moon{} suit",
					"to give {X:mult,C:white}X#3#{} mult when scored"
                }
            },
            ability_name = "moonStone",
            slug = "moonst",
            ability = {
                extra = {odds = 2, Xmult = 1.5}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Moon Stone
        local joker_most = SMODS.Joker:new(
            most.ability_name,
            most.slug,
            most.ability,
            { x = 0, y = 0 },
            most.loc,
            most.rarity,
            most.cost,
            most.unlocked,
            most.discovered,
            most.blueprint_compat,
            most.eternal_compat,
            nil,
            most.slug
        )
        joker_most:register()

        -- Initialize Sprite for Jokers
        local sprite_most = SMODS.Sprite:new(
            most.slug,
            flounderJokers.path,
            "j_" .. most.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_most:register()

        -- Set local variables for Moon Stone
        function joker_most.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1),self.ability.extra.Xmult}
        end
        -- Calculate
        joker_most.calculate = function(self, context)
	       if self.ability.name ==  'moonStone' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Moons") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then
                        if FJ_EFFECT then FJ_EFFECT(self) end
                        return {
                            x_mult = self.ability.extra.Xmult,
                            card = self
                        }
                    end
                end
	        end
		end
	end
    if mod_loaded('SixSuit') and config.spaceLaser then
        -- Create Space Laser
        local spla = {
            loc = {
                name = "Space Laser",
                text = {
                    "Played cards with",
                    "{C:moons}Moon{} suit give",
					"{C:chips}+#1#{} Chips when scored"
                }
            },
            ability_name = "spaceLaser",
            slug = "spacel",
            ability = {
                extra = {chips = 50}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Space Laser
        local joker_spla = SMODS.Joker:new(
            spla.ability_name,
            spla.slug,
            spla.ability,
            { x = 0, y = 0 },
            spla.loc,
            spla.rarity,
            spla.cost,
            spla.unlocked,
            spla.discovered,
            spla.blueprint_compat,
            spla.eternal_compat,
            nil,
            spla.slug
        )
        joker_spla:register()

        -- Initialize Sprite for Jokers
        local sprite_spla = SMODS.Sprite:new(
            spla.slug,
            flounderJokers.path,
            "j_" .. spla.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_spla:register()

        -- Set local variables for Space Laser
        function joker_spla.loc_def(self)
            return { self.ability.extra.chips}
        end
		-- Calculate
        joker_spla.calculate = function(self, context)
	       if self.ability.name ==  'spaceLaser' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Moons") then
                    return {
                        chips = self.ability.extra.chips,
                        card = self
                    }		
				end
			end
		end
	end
    if mod_loaded('SixSuit') and config.apolloGem then
	    -- Create Apollo Gem
        local apge = {
            loc = {
                name = "Apollo Gem",
                text = {
                    "Played cards with",
                    "{C:moons}Moon{} suit give",
					"{C:money}$#1#{} when scored"
                }
            },
            ability_name = "apolloGem",
            slug = "apollog",
            ability = {
                extra = {money = 1}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Apollo Gem
        local joker_apge = SMODS.Joker:new(
            apge.ability_name,
            apge.slug,
            apge.ability,
            { x = 0, y = 0 },
            apge.loc,
            apge.rarity,
            apge.cost,
            apge.unlocked,
            apge.discovered,
            apge.blueprint_compat,
            apge.eternal_compat,
            nil,
            apge.slug
        )
        joker_apge:register()

        -- Initialize Sprite for Jokers
        local sprite_apge = SMODS.Sprite:new(
            apge.slug,
            flounderJokers.path,
            "j_" .. apge.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_apge:register()

        -- Set local variables for Apollo Gem
        function joker_apge.loc_def(self)
            return { self.ability.extra.money}
        end
		-- Calculate
        joker_apge.calculate = function(self, context)
	       if self.ability.name ==  'apolloGem' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Moons") then
                    G.GAME.dollar_buffer = (G.GAME.dollar_buffer or 0) + self.ability.extra.money
					G.E_MANAGER:add_event(Event({func = (function() G.GAME.dollar_buffer = 0; return true end)}))
                    return {
                        dollars = self.ability.extra.money,
                        card = self
                    }		
				end
			end
		end
	end
    if mod_loaded('SixSuit') and config.meteorPiece then
        -- Create Meteor Piece
        local mepi = {
            loc = {
                name = "Meteor Piece",
                text = {
                    "Played cards with",
                    "{C:moons}Moon{} suit give",
					"{C:mult}+#1#{} Mult when scored"
                }
            },
            ability_name = "meteorPiece",
            slug = "meteorpi",
            ability = {
                extra = {mult = 7}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Meteor Piece
        local joker_mepi = SMODS.Joker:new(
            mepi.ability_name,
            mepi.slug,
            mepi.ability,
            { x = 0, y = 0 },
            mepi.loc,
            mepi.rarity,
            mepi.cost,
            mepi.unlocked,
            mepi.discovered,
            mepi.blueprint_compat,
            mepi.eternal_compat,
            nil,
            mepi.slug
        )
        joker_mepi:register()

        -- Initialize Sprite for Jokers
        local sprite_mepi = SMODS.Sprite:new(
            mepi.slug,
            flounderJokers.path,
            "j_" .. mepi.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_mepi:register()

        -- Set local variables for Meteor Piece
        function joker_mepi.loc_def(self)
            return { self.ability.extra.mult}
        end
		-- Calculate
        joker_mepi.calculate = function(self, context)
	       if self.ability.name ==  'meteorPiece' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Moons") then
                    return {
                        mult = self.ability.extra.mult,
                        card = self
                    }		
				end
			end
		end
	end
    if mod_loaded('SixSuit') and config.moonandSun then
        -- Create Moon and Sun
        local mosu = {
            loc = {
                name = "Moon and Sun",
                text = {
                    "Retriggers all",
					"played {C:moons}Moon{} cards"
                }
            },
            ability_name = "moonandSun",
            slug = "moonan",
            ability = {
                extra = {loop_amount = 1}
            },
            rarity = 3,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Moon and Sun
        local joker_mosu = SMODS.Joker:new(
            mosu.ability_name,
            mosu.slug,
            mosu.ability,
            { x = 0, y = 0 },
            mosu.loc,
            mosu.rarity,
            mosu.cost,
            mosu.unlocked,
            mosu.discovered,
            mosu.blueprint_compat,
            mosu.eternal_compat,
            nil,
            mosu.slug
        )
        joker_mosu:register()

        -- Initialize Sprite for Jokers
        local sprite_mosu = SMODS.Sprite:new(
            mosu.slug,
            flounderJokers.path,
            "j_" .. mosu.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_mosu:register()

        -- Set local variables for Moon and Sun
        function joker_mosu.loc_def(card)
            return { card.ability.extra.loop_amount}
        end
		-- Calculate
        joker_mosu.calculate = function(self, context)
	        if context.repetition and context.cardarea == G.play then
                if context.other_card and context.other_card:is_suit("Moons") then
                    return {
                        message = localize('k_again_ex'),
                        repetitions = 1,
                        card = self
                    }		
			    end
			end
	    end
    end
    if mod_loaded('SixSuit') and config.mathMatician then
	
	    -- Create Mathmatician
        local mama = {
            loc = {
                name = "Mathematician",
                text = {
                    "All {C:moons}Moon{} suit cards have",
					"{C:green}#2# in #1#{} chance to",  
                    "become {C:mult}Mult{} cards",
                    "when played"
                }
            },
            ability_name = "mathMatician",
            slug = "mathma",
            ability = {
                extra = {odds = 10}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Mathmatician
        local joker_mama = SMODS.Joker:new(
            mama.ability_name,
            mama.slug,
            mama.ability,
            { x = 0, y = 0 },
            mama.loc,
            mama.rarity,
            mama.cost,
            mama.unlocked,
            mama.discovered,
            mama.blueprint_compat,
            mama.eternal_compat,
            nil,
            mama.slug
        )
        joker_mama:register()

        -- Initialize Sprite for Jokers
        local sprite_mama = SMODS.Sprite:new(
            mama.slug,
            flounderJokers.path,
            "j_" .. mama.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_mama:register()

        -- Set local variables for Mathmatician
        function joker_mama.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1)}
        end
        -- Calculate
        joker_mama.calculate = function(self, context)
	       if self.ability.name ==  'mathMatician' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Moons") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then				
                        if FJ_EFFECT then FJ_EFFECT(self) end
                        for k, v in ipairs(context.full_hand) do
                            if v:is_suit("Moons") then
                                v:set_ability(G.P_CENTERS.m_mult, nil, true)
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        v:juice_up()
                                        return true
                                    end
						        }))        
                            end
                        end
	                end
		        end
	        end
        end
    end
     if mod_loaded('SixSuit') and config.sunStone then
	
	    -- Create Sun Stone
        local sust = {
            loc = {
                name = "Sun Stone",
                text = {
                    "{C:green}#2# in #1#{} chance for",
                    "played cards with {C:stars}Star{} suit",
					"to give {X:mult,C:white}X#3#{} mult when scored"
                }
            },
            ability_name = "sunStone",
            slug = "sunst",
            ability = {
                extra = {odds = 2, Xmult = 1.5}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Sun Stone
        local joker_sust = SMODS.Joker:new(
            sust.ability_name,
            sust.slug,
            sust.ability,
            { x = 0, y = 0 },
            sust.loc,
            sust.rarity,
            sust.cost,
            sust.unlocked,
            sust.discovered,
            sust.blueprint_compat,
            sust.eternal_compat,
            nil,
            sust.slug
        )
        joker_sust:register()

        -- Initialize Sprite for Jokers
        local sprite_sust = SMODS.Sprite:new(
            sust.slug,
            flounderJokers.path,
            "j_" .. sust.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_sust:register()

        -- Set local variables for Sun Stone
        function joker_sust.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1),self.ability.extra.Xmult}
        end
        -- Calculate
        joker_sust.calculate = function(self, context)
	       if self.ability.name ==  'sunStone' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Stars") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then
                        if FJ_EFFECT then FJ_EFFECT(self) end
                        return {
                            x_mult = self.ability.extra.Xmult,
                            card = self
                        }
                    end
                end
	        end
		end
	end
    if mod_loaded('SixSuit') and config.solarFlare then
        -- Create Solar Flare
        local sofl = {
            loc = {
                name = "Solar Flare",
                text = {
                    "Played cards with",
                    "{C:stars}Star{} suit give",
					"{C:chips}+#1#{} Chips when scored"
                }
            },
            ability_name = "solarFlare",
            slug = "solarf",
            ability = {
                extra = {chips = 50}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Solar Flare
        local joker_sofl = SMODS.Joker:new(
            sofl.ability_name,
            sofl.slug,
            sofl.ability,
            { x = 0, y = 0 },
            sofl.loc,
            sofl.rarity,
            sofl.cost,
            sofl.unlocked,
            sofl.discovered,
            sofl.blueprint_compat,
            sofl.eternal_compat,
            nil,
            sofl.slug
        )
        joker_sofl:register()

        -- Initialize Sprite for Jokers
        local sprite_sofl = SMODS.Sprite:new(
            sofl.slug,
            flounderJokers.path,
            "j_" .. sofl.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_sofl:register()

        -- Set local variables for Solar Flare
        function joker_sofl.loc_def(self)
            return { self.ability.extra.chips}
        end
		-- Calculate
        joker_sofl.calculate = function(self, context)
	       if self.ability.name ==  'solarFlare' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Stars") then
                    return {
                        chips = self.ability.extra.chips,
                        card = self
                    }		
				end
			end
		end
	end
    if mod_loaded('SixSuit') and config.radiationGem then
	    -- Create Radiation Gem
        local rage = {
            loc = {
                name = "Radiation Gem",
                text = {
                    "Played cards with",
                    "{C:stars}Star{} suit give",
					"{C:money}$#1#{} when scored"
                }
            },
            ability_name = "radiationGem",
            slug = "radge",
            ability = {
                extra = {money = 1}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Radiation Gem
        local joker_rage = SMODS.Joker:new(
            rage.ability_name,
            rage.slug,
            rage.ability,
            { x = 0, y = 0 },
            rage.loc,
            rage.rarity,
            rage.cost,
            rage.unlocked,
            rage.discovered,
            rage.blueprint_compat,
            rage.eternal_compat,
            nil,
            rage.slug
        )
        joker_rage:register()

        -- Initialize Sprite for Jokers
        local sprite_rage = SMODS.Sprite:new(
            rage.slug,
            flounderJokers.path,
            "j_" .. rage.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_rage:register()

        -- Set local variables for Radiation Gem
        function joker_rage.loc_def(self)
            return { self.ability.extra.money}
        end
		-- Calculate
        joker_rage.calculate = function(self, context)
	       if self.ability.name ==  'radiationGem' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Moons") then
                    G.GAME.dollar_buffer = (G.GAME.dollar_buffer or 0) + self.ability.extra.money
					G.E_MANAGER:add_event(Event({func = (function() G.GAME.dollar_buffer = 0; return true end)}))
                    return {
                        dollars = self.ability.extra.money,
                        card = self
                    }		
				end
			end
		end
	end
    if mod_loaded('SixSuit') and config.starPlasma then
        -- Create Star Plasma
        local stpl = {
            loc = {
                name = "Star Plasma",
                text = {
                    "Played cards with",
                    "{C:stars}Star{} suit give",
					"{C:mult}+#1#{} Mult when scored"
                }
            },
            ability_name = "starPlasma",
            slug = "starpl",
            ability = {
                extra = {mult = 7}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Star Plasma
        local joker_stpl = SMODS.Joker:new(
            stpl.ability_name,
            stpl.slug,
            stpl.ability,
            { x = 0, y = 0 },
            stpl.loc,
            stpl.rarity,
            stpl.cost,
            stpl.unlocked,
            stpl.discovered,
            stpl.blueprint_compat,
            stpl.eternal_compat,
            nil,
            stpl.slug
        )
        joker_stpl:register()

        -- Initialize Sprite for Jokers
        local sprite_stpl = SMODS.Sprite:new(
            stpl.slug,
            flounderJokers.path,
            "j_" .. stpl.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_stpl:register()

        -- Set local variables for Star Plasma
        function joker_stpl.loc_def(self)
            return { self.ability.extra.mult}
        end
		-- Calculate
        joker_stpl.calculate = function(self, context)
	       if self.ability.name ==  'starPlasma' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Stars") then
                    return {
                        mult = self.ability.extra.mult,
                        card = self
                    }		
				end
			end
		end
	end
    if mod_loaded('SixSuit') and config.sunandMoon then
        -- Create Sun and Moon
        local sumo = {
            loc = {
                name = "Sun and Moon",
                text = {
                    "Retriggers all",
					"played {C:stars}Star{} cards"
                }
            },
            ability_name = "sunandMoon",
            slug = "sunan",
            ability = {
                extra = {loop_amount = 1}
            },
            rarity = 3,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize Sun and Moon
        local joker_sumo = SMODS.Joker:new(
            sumo.ability_name,
            sumo.slug,
            sumo.ability,
            { x = 0, y = 0 },
            sumo.loc,
            sumo.rarity,
            sumo.cost,
            sumo.unlocked,
            sumo.discovered,
            sumo.blueprint_compat,
            sumo.eternal_compat,
            nil,
            sumo.slug
        )
        joker_sumo:register()

        -- Initialize Sprite for Jokers
        local sprite_sumo = SMODS.Sprite:new(
            sumo.slug,
            flounderJokers.path,
            "j_" .. sumo.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_sumo:register()

        -- Set local variables for Sun and Moon
        function joker_sumo.loc_def(card)
            return { card.ability.extra.loop_amount}
        end
		-- Calculate
        joker_sumo.calculate = function(self, context)
	        if context.repetition and context.cardarea == G.play then
                if context.other_card and context.other_card:is_suit("Stars") then
                    return {
                        message = localize('k_again_ex'),
                        repetitions = 1,
                        card = self
                    }		
			    end
			end
	    end
    end
    if mod_loaded('SixSuit') and config.theBoss then
	
	    -- Create The Boss
        local thbo = {
            loc = {
                name = "The Boss",
                text = {
                    "All {C:stars}Star{} suit cards have",
					"{C:green}#2# in #1#{} chance to",  
                    "become {C:chips}Bonus{} cards",
                    "when played"
                }
            },
            ability_name = "theBoss",
            slug = "thebo",
            ability = {
                extra = {odds = 10}
            },
            rarity = 2,
            cost = 6,
            unlocked = true,
            discovered = true,
            blueprint_compat = true,
            eternal_compat = true
        }

        -- Initialize The Boss
        local joker_thbo = SMODS.Joker:new(
            thbo.ability_name,
            thbo.slug,
            thbo.ability,
            { x = 0, y = 0 },
            thbo.loc,
            thbo.rarity,
            thbo.cost,
            thbo.unlocked,
            thbo.discovered,
            thbo.blueprint_compat,
            thbo.eternal_compat,
            nil,
            thbo.slug
        )
        joker_thbo:register()

        -- Initialize Sprite for Jokers
        local sprite_thbo = SMODS.Sprite:new(
            thbo.slug,
            flounderJokers.path,
            "j_" .. thbo.slug .. ".png",
            71,
            95,
            "asset_atli"
        )
        sprite_thbo:register()

        -- Set local variables for The Boss
        function joker_thbo.loc_def(self)
            return { self.ability.extra.odds, '' .. (G.GAME and G.GAME.probabilities.normal or 1)}
        end
        -- Calculate
        joker_thbo.calculate = function(self, context)
	       if self.ability.name ==  'theBoss' then
		        if context.cardarea == G.play and not context.repetition and context.other_card and context.other_card:is_suit("Stars") then
                    if fj_roll(self) < G.GAME.probabilities.normal/self.ability.extra.odds then				
                        if FJ_EFFECT then FJ_EFFECT(self) end
                        for k, v in ipairs(context.full_hand) do
                            if v:is_suit("Stars") then
                                v:set_ability(G.P_CENTERS.m_bonus, nil, true)
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        v:juice_up()
                                        return true
                                    end
						        }))        
                            end
                        end
	                end
		        end
	        end
        end
    end
end
	
----------------------------------------------
------------MOD CODE END---------------------
